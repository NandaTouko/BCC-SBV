#include <stdio.h>
#include <stdlib.h>

int main() {
    printf("Ola Mundo!");

    return 0; // sempre a �ltima instru��o
}
