#ifndef FUNC_H_
#define FUNC_H_

void gerarArrayAleatorio(int array[], int tamArray);
void imprimeArray(int array[], int tamArray);
void encontrarPosicao(int array[], int tamArray, int valBusca);

#endif